/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.List;

/**
 *
 * @author 07201242
 */
public interface LivroDAO {
	List<Livro> buscarTodos() throws DAOLivroException;
        Livro buscarPorCodigo(int codigo) throws DAOLivroException;
}
