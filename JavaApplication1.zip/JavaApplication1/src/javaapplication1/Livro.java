/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author 07201242
 */
public class Livro {
    	private	int codigo;
	private String nome;
	private String autor;
	private float valor;
	private double codbarras;
	private int edicao;

public Livro(String n, String a, float v, double cb, int e){
		this.nome = n;
		this.autor = a;
		this.valor = v;
		this.codbarras = cb;
		this.edicao = e;
	}



public String getNome(){
    return this.nome;
   
}

}
