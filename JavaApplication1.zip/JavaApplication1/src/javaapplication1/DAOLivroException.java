/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author 07201242
 */
public class DAOLivroException extends Exception{
    	public DAOLivroException(){
		super();
	}
	public DAOLivroException(String mensagem) {
		super(mensagem);
	}
	public DAOLivroException(String mensagem, Throwable causa) {
		super(mensagem, causa);
	}
}
